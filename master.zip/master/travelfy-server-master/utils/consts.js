const MONGODB_URI = process.env.MONGODB_URI || "mongodb://localhost/travelfy-back";

module.exports = MONGODB_URI;
